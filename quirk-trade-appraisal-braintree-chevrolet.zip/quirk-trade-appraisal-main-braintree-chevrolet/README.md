Trade Appraisal Tool
